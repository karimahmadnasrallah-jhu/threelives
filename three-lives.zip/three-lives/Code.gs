/**
 * Three Lives backend (Google Apps Script).
 * Paste this whole file into Extensions > Apps Script in your Google Sheet, then deploy as a web app.
 * See README.md for the step by step.
 */
const SHEET_NAME = "Submissions";
const HEADERS = ["Timestamp", "Session", "Name", "Year & Major", "Share on gallery", "Show name",
  "Life 1 title", "Life 1 timeline", "Life 1 questions", "Life 1 resources", "Life 1 like it", "Life 1 confidence", "Life 1 fits me",
  "Life 2 title", "Life 2 timeline", "Life 2 questions", "Life 2 resources", "Life 2 like it", "Life 2 confidence", "Life 2 fits me",
  "Life 3 title", "Life 3 timeline", "Life 3 questions", "Life 3 resources", "Life 3 like it", "Life 3 confidence", "Life 3 fits me",
  "Raw JSON"];

function sheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) sh = ss.insertSheet(SHEET_NAME);
  if (sh.getLastRow() === 0) {
    sh.appendRow(HEADERS);
    sh.getRange(1, 1, 1, HEADERS.length).setFontWeight("bold").setBackground("#4A2346").setFontColor("#FFFFFF");
    sh.setFrozenRows(1);
  }
  return sh;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function clip_(s, n) { return String(s || "").slice(0, n); }

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(10000);
    const d = JSON.parse(e.postData.contents);
    const lives = (d.lives || []).slice(0, 3);
    if (lives.length !== 3) return json_({ ok: false, error: "Expected three lives" });
    const row = [new Date(), clip_(d.session, 100), clip_(d.name, 80), clip_(d.major, 80), !!d.share, !!d.showName];
    lives.forEach(l => {
      const tl = [1, 2, 3, 4, 5].map(y => l["y" + y] ? `Year ${y}: ${clip_(l["y" + y], 400)}` : "").filter(String).join("\n");
      row.push(clip_(l.title, 80), tl, clip_(l.questions, 800),
        +l.resources || "", +l.like || "", +l.confidence || "", +l.coherence || "");
    });
    row.push(JSON.stringify(d).slice(0, 45000));
    sheet_().appendRow(row);
    return json_({ ok: true });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  } finally {
    lock.releaseLock();
  }
}

// Gallery feed: only submissions where the person agreed to share. Names only if they opted in.
function doGet(e) {
  if (!e || !e.parameter || e.parameter.action !== "list") return json_({ ok: true, hello: "Three Lives backend is running" });
  const sh = sheet_();
  const n = sh.getLastRow() - 1;
  if (n < 1) return json_({ ok: true, items: [] });
  const vals = sh.getRange(2, 1, n, HEADERS.length).getValues();
  const items = [];
  vals.reverse().forEach(r => {
    if (r[4] !== true) return;
    try {
      const d = JSON.parse(r[HEADERS.length - 1]);
      items.push({ name: r[5] === true ? d.name : "", major: d.major || "", lives: d.lives });
    } catch (x) {}
  });
  return json_({ ok: true, items: items.slice(0, 200) });
}
