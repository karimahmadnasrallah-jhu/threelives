# Three Lives

A small site for the Three Lives (Odyssey Plan) exercise at Life Design Lab peer educator training.

* `index.html`: the form where people sketch their three lives
* `gallery.html`: a live wall of everyone who chose to share (good for projecting)
* `config.js`: the one file you edit
* `Code.gs`: the Google Apps Script backend (it lives in Google, not on GitHub)

Submissions go to a Google Sheet. That Sheet is where you see everything, including people who chose not to share on the gallery.

## Setup (about 10 minutes)

### 1. Make the Google Sheet
1. Create a new Google Sheet, for example "Three Lives Submissions".
2. Click **Extensions → Apps Script**.
3. Delete the starter code, paste in everything from `Code.gs`, and click **Save**.

### 2. Deploy it as a web app
1. Click **Deploy → New deployment**.
2. Click the gear next to "Select type" and pick **Web app**.
3. Set **Execute as: Me** and **Who has access: Anyone**.
4. Click **Deploy**, then authorize with your Google account. If you see "Google hasn't verified this app," click **Advanced → Go to project**.
5. Copy the **Web app URL**. It ends in `/exec`.

### 3. Connect the site
1. Open `config.js` and paste the URL between the quotes:
   ```js
   SCRIPT_URL: "https://script.google.com/macros/s/XXXX/exec",
   ```
2. Change `SESSION` if you want a different label at the top of the page.

### 4. Put it on GitHub Pages
1. Create a new repo, for example `threelives`.
2. Upload `index.html`, `gallery.html`, `style.css` and `config.js`. You can leave out `Code.gs` and this README.
3. Go to **Settings → Pages**, set the source to **Deploy from a branch**, branch `main`, folder `/ (root)`, and save.
4. After a minute your site is live at `https://<your-username>.github.io/threelives/`.

## Seeing submissions
* **Everything:** open the Google Sheet. The "Submissions" tab shows one row per person with all three lives, timelines, questions and gut check ratings.
* **Gallery:** `gallery.html` shows only people who left "Show my lives on the gallery" checked. Names appear only if they also checked "Show my name." It refreshes every 20 seconds.

## Good to know
* If you edit `Code.gs` later, use **Deploy → Manage deployments → Edit → New version**. Otherwise the URL keeps running the old code.
* The gallery is public to anyone with the link. Hide it by not sharing `gallery.html`, or delete that file from the repo.
* With `SCRIPT_URL` left empty, the site runs in demo mode: submissions save only in that browser. That's handy for testing.
* To reset for a new session, clear the rows below the header in the Sheet.
