// Paste your Google Apps Script web app URL between the quotes (see README.md).
// Leave it empty to try the site in demo mode: submissions save only in your own browser.
window.THREE_LIVES_CONFIG = {
  SCRIPT_URL: "",
  SESSION: "Peer Ed Training, Nov 14"
};
